package com.srsajib.ecah;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Register extends AppCompatActivity {

    private static final String TAG = "TAG";
    private EditText mFullName, mNumber, mEmail, mPassword, mConfirmpuss;
    Button mRegisterBtn;
    TextView mLoginBtn;
    FirebaseAuth fAuth;
    ProgressBar progressBar;
    //FirebaseFirestore fStore;
    //LinearLayout pinViewLeyout, regleyout;
    //PinView pinView, Button;
    //int code;
    //Button button, confirmbtn;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference reference;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        getSupportActionBar().hide();

        //pinViewLeyout = findViewById(R.id.LinearLayout_PinView);
        //pinView = findViewById(R.id.firstPinView);

        mFullName = findViewById(R.id.fullName);
        mEmail = findViewById(R.id.Email);
        mNumber = findViewById(R.id.Number);
        mPassword = findViewById(R.id.password);
        mConfirmpuss = findViewById(R.id.confirmPass);
        mRegisterBtn = findViewById(R.id.registerBtn);
        mLoginBtn = findViewById(R.id.createText);
        progressBar = findViewById(R.id.progressBar);
        // button=findViewById(R.id.signup_confirm);
        //regleyout=findViewById(R.id.regleyout);


        mRegisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = mEmail.getText().toString();
                String password = mPassword.getText().toString();
                String fullname = mFullName.getText().toString();
                String confirmPass = mConfirmpuss.getText().toString();
                String number = mNumber.getText().toString();

                if (TextUtils.isEmpty(fullname)) {
                    mFullName.setError("Full Name is Required");
                    mFullName.requestFocus();
                } else if (TextUtils.isEmpty(number)) {
                    mNumber.setError("Number is Required");
                    mNumber.requestFocus();
                } else if (number.length() != 11) {
                    mNumber.setError("Mobile Number should be 11 digits");
                    mNumber.requestFocus();
                } else if (!Patterns.PHONE.matcher(number).matches()) {
                    mNumber.setError("Valid Number is Required");
                    mNumber.requestFocus();
                } else if (TextUtils.isEmpty(email)) {
                    mEmail.setError("Email is Required");
                    mEmail.requestFocus();
                } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    mEmail.setError("Valid Email is Required");
                    mEmail.requestFocus();
                } else if (TextUtils.isEmpty(password)) {
                    mPassword.setError("Password is Required");
                    mPassword.requestFocus();
                } else if (password.length() < 6) {
                    mPassword.setError("Password Must be >= 6 Characters");
                    mPassword.requestFocus();
                } else if (confirmPass.isEmpty() || !password.equals(confirmPass)) {
                    mConfirmpuss.setError("Invalid Password");
                    mConfirmpuss.requestFocus();

                    mPassword.clearComposingText();
                    mConfirmpuss.clearComposingText();
                } else {
                    progressBar.setVisibility(View.GONE);
                    registerUser(fullname, email, number, password);
                }
            }
        });


        mLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Login.class));
            }
        });


    }

    private void registerUser(String fullName, String email, String number, String password) {
        FirebaseAuth auth = FirebaseAuth.getInstance();
        auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    FirebaseUser firebaseUser = auth.getCurrentUser();

                    HelperClass helperClass = new HelperClass(fullName, email, number, password);
                    DatabaseReference referenceProfile = FirebaseDatabase.getInstance().getReference("Registered Users");

                    referenceProfile.child(firebaseUser.getUid()).setValue(helperClass).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                firebaseUser.sendEmailVerification();
                                Toast.makeText(Register.this, "Email Varification is Send", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(Register.this, Login.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivitySecond();
                            } else {
                                Toast.makeText(Register.this, "Error!... Email Varification is not Send", Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.GONE);
                            }
                        }
                    });

                } else {
                    //Toast.makeText(RegisterActivity.this, "Error...! Email already used", Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.GONE);

                    try {
                        throw task.getException();
                    } catch (FirebaseAuthWeakPasswordException e) {
                        mPassword.setError("Your password is too weak, Used number and special characters");
                        mPassword.requestFocus();
                    } catch (FirebaseAuthInvalidCredentialsException e) {
                        mEmail.setError("Your Email is invalid or already used");
                        mEmail.requestFocus();
                    } catch (FirebaseAuthUserCollisionException e) {
                        mEmail.setError("User is already Registered with this email");
                        mEmail.requestFocus();
                    } catch (Exception e) {
                        Log.e(TAG, e.getMessage());
                        Toast.makeText(Register.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
    }

    private void startActivitySecond() {
        Intent intent = new Intent(Register.this, Login.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}