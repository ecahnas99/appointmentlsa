package com.srsajib.ecah;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();
        // Initialize logout button
        Button logout = findViewById(R.id.logoutBtn);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle logout
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(getApplicationContext(), Login.class));
                finish();
            }
        });

        // Initialize View Appointment button
        Button viewAppointmentButton = findViewById(R.id.buttonViewAppointment);
        viewAppointmentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open StudentViewActivity when the button is clicked
                Intent intent = new Intent(MainActivity.this, StudentViewApp.class);
                startActivity(intent);
            }
        });

        // Initialize Book Appointment button
        Button timeSlotButton = findViewById(R.id.buttonTimeSlot);
        timeSlotButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open StudentViewActivity when the button is clicked
                Intent intent = new Intent(MainActivity.this, BookAppointment.class);
                startActivity(intent);
            }
        });
    }
}
