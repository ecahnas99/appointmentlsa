package com.srsajib.ecah;

public class HelperClass {

    public String fullName, email, number, password;

    public HelperClass(){};

    public HelperClass(String fullname, String email, String number, String password) {
        this.fullName = fullname;
        this.email = email;
        this.number = number;
        this.password = password;
    }
}