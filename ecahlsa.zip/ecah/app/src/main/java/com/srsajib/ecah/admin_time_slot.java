package com.srsajib.ecah;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;


import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;


public class admin_time_slot extends AppCompatActivity {

    private TextView selectedDateTextView;
    private EditText timeSlotEditText;
    private LinearLayout timeSlotLinearLayout;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_time_slot);
        FirebaseFirestore db = FirebaseFirestore.getInstance();


        selectedDateTextView = findViewById(R.id.selectedDateTextView);
        timeSlotEditText = findViewById(R.id.timeSlotEditText);
        timeSlotLinearLayout = findViewById(R.id.timeSlotLinearLayout);

        Button selectDateButton = findViewById(R.id.selectDateButton);
        selectDateButton.setOnClickListener(v -> showDatePickerDialog());

        Button addTimeSlotButton = findViewById(R.id.addTimeSlotButton);
        addTimeSlotButton.setOnClickListener(v -> addTimeSlot());

        Button saveButton = findViewById(R.id.saveButton);
        saveButton.setOnClickListener(v -> saveTimeSlots());
    }

    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year1, month1, dayOfMonth) -> {
                    String selectedDate = dayOfMonth + "/" + (month1 + 1) + "/" + year1;
                    selectedDateTextView.setText(selectedDate);
                }, year, month, day);
        datePickerDialog.show();
    }

    private void addTimeSlot() {
        String timeSlot = timeSlotEditText.getText().toString();
        if (!timeSlot.isEmpty()) {
            CheckBox checkBox = new CheckBox(this);
            checkBox.setText(timeSlot);
            timeSlotLinearLayout.addView(checkBox);
            timeSlotEditText.setText("");  // Clear the input field
        } else {
            Toast.makeText(admin_time_slot.this, "Time slot cannot be empty", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveTimeSlots() {
        int count = timeSlotLinearLayout.getChildCount();
        if (count > 0) {
            ArrayList<String> timeSlots = new ArrayList<>();
            for (int i = 0; i < count; i++) {
                CheckBox checkBox = (CheckBox) timeSlotLinearLayout.getChildAt(i);
                if (checkBox.isChecked()) {
                    timeSlots.add(checkBox.getText().toString());
                }
            }
            String selectedDate = selectedDateTextView.getText().toString();

            // Ensure a non-empty selected date
            if (TextUtils.isEmpty(selectedDate)) {
                Toast.makeText(this, "Please select a date", Toast.LENGTH_SHORT).show();
                return;
            }

            // Generate a custom ID
            String documentId = "timeSlot" + selectedDate.replace("/", "_") + "_" + System.currentTimeMillis();

            // Prepare data to save
            Map<String, Object> timeSlotData = new HashMap<>();
            timeSlotData.put("date", selectedDate);
            timeSlotData.put("timeSlots", timeSlots);

            // Save to Fire store
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            db.collection("timeSlots").document(documentId).set(timeSlotData)
                    .addOnSuccessListener(aVoid -> {
                        String message = "Saved Date: " + selectedDate + "\nTime Slots:\n" + timeSlots;
                        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Error saving time slots", Toast.LENGTH_SHORT).show());
        } else {
            Toast.makeText(this, "No time slots to save", Toast.LENGTH_SHORT).show();
        }
    }

}

