package com.srsajib.ecah;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class LecturerLogin extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;

    private static final String TAG ="TAG";
    private EditText mNumber, mPassword;
    Button mLoginBtn;
    TextView mCreateBtn,forgetTextLink, JbLec;
    private FirebaseAuth authProfile;
    ProgressBar progressBar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lecturer_login);

        getSupportActionBar().hide();


        mNumber = findViewById(R.id.IdLecturer);
        mPassword = findViewById(R.id.password);
        mCreateBtn = findViewById(R.id.createText);
        mLoginBtn = findViewById(R.id.loginBtn);
        progressBar = findViewById(R.id.progressBar);
        forgetTextLink = findViewById(R.id.forgotPassword);
        JbLec = findViewById(R.id.LecturerID);







        mLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number = mNumber.getText().toString().trim();
                String password = mPassword.getText().toString().trim();

                if (TextUtils.isEmpty(number)) {
                    mNumber.setError("Lecturer ID is Required");
                    mNumber.requestFocus();
                }
                else if (TextUtils.isEmpty(password)) {
                    mPassword.setError("Password is Required");
                    mPassword.requestFocus();
                }
                else if (password.length()<4) {
                    mPassword.setError("Password Must be >= 4 Characters");
                    mPassword.requestFocus();
                }else {
                    progressBar.setVisibility(View.VISIBLE);
                    //loginUser(email, password);

                    DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Lecturer");
                    Query checkUser = reference.orderByChild("number").equalTo(number);

                    checkUser.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if(snapshot.exists()){
                                mNumber.setError(null);
                                String tpassword =snapshot.child(number).child("password").getValue(String.class);
                                if(Objects.equals(tpassword,password)){
                                    mNumber.setError(null);
                                    Intent intent = new Intent(LecturerLogin.this, admin_time_slot.class);
                                    startActivity(intent);
                                    progressBar.setVisibility(View.GONE);
                                }
                                else {
                                    Toast.makeText(LecturerLogin.this, "Wrong Password", Toast.LENGTH_SHORT).show();
                                    progressBar.setVisibility(View.GONE);
                                }
                            }
                            else {
                                Toast.makeText(LecturerLogin.this, "Wrong Password", Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.GONE);
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                }
            }

        }); //oneclick Close

        mCreateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), LecturerRegister.class));
            }
        });

    }
}