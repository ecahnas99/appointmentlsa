package com.srsajib.ecah;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class StudentViewApp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_view_app);

        getSupportActionBar().hide();
    }
}